# .jar ohne Installation bauen lassen (GitHub)

1. Account auf https://github.com erstellen (kostenlos) und einloggen.
2. Oben rechts "+" -> "New repository". Name: battleloot, Haken bei "Add a README" NICHT setzen -> "Create repository".
3. Auf der leeren Repo-Seite "uploading an existing file" anklicken.
4. ZIP entpacken und ALLE Dateien/Ordner aus dem Ordner "BattleLoot" ins Browserfenster ziehen
   (build.gradle, src, ... ). Unten "Commit changes".
5. Pruefen, ob unter .github/workflows/build.yml existiert. Falls nicht (versteckte Ordner werden
   manchmal nicht hochgeladen): "Add file" -> "Create new file", als Namen
   .github/workflows/build.yml eintippen und den Inhalt der Datei aus dem ZIP einfuegen.
6. Oben Reiter "Actions" -> der Build "Build Mod" laeuft (ca. 3-6 Minuten, gelber Punkt -> gruener Haken).
7. Auf den fertigen Lauf klicken -> unten bei "Artifacts" "BattleLoot-jar" herunterladen -> entpacken.
8. Die .jar in den mods-Ordner von Minecraft 1.20.1 mit Forge 47.2.0 legen.
